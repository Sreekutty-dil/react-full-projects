import React , { Component } from 'react';
import "./App.css"
import ReactDOM  from 'react-dom';
import Counter from './Component/Counter';

class App extends Component {
  constructor(props) {
    super(props);
  }

  //monting Component
mountHandler() {
   //ReactDOM.render(component,target)
   ReactDOM.render(<React.StrictMode>
    <Counter />
   </React.StrictMode>,
   document.getElementById('renderHere'))
   console.log(`counted component mounted`)
}
  //unmounting Component
  unmountHandler() {
    ReactDOM.unmountComponentAtNode(document.getElementById('renderHere'))
    console.log(`counted component unmounted`)
  }

  render() {
    return (
      <div className="container">
        <div className="title">
          <h1>React Lifecycle</h1>
        </div>

        <div className="btn-group">
          <button onClick={this.mountHandler.bind(this)} className='btn btn-success'>Mount</button>
          <button onClick={this.unmountHandler.bind(this)} className='btn btn-danger'>Un-Mount</button>
        </div>

        <section id="renderHere"></section>

      </div>


    )
  }
}

export default App;