import React , { Component } from 'react';
import ReactDOM from 'react-dom';

export default class Counter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            view: false // initial state
        };
        console.log(`constuctor Called`)
    }

    //increment handlers
    incProps() {
        ReactDOM.render(<React.StrictMode>
            <Counter num={this.props.num + 1} />
           </React.StrictMode>,
           document.getElementById('renderHere'))
    }

    //mount stage method
    componentDidMount() {
        console.log(`compount did mount called`)
    }

    //update stage method nP newProps, nS newState , nC newContext
    shouldComponentUpdate(nP,nS,nC) {
        console.log(`should component update or not ?`)
        console.log(`newProps =`, nP)
        console.log(`newState =`, nS)
        return true
    }

    // pre-commit
    getSnapshotBeforeUpdate(oP,oS) {
        console.log(`get Snapshot before called`)
        console.log(`oldProps =`, oP)
        console.log(`oldState =`, oS) 
    }

    // commit
    componentDidUpdate(oP,oS) {
        console.log(`compount didupdate called`)
        console.log(`oldProps =`, oP)
        console.log(`oldState =`, oS)
    }

    //unmounted stage method
    componentWillUnmount() {
        console.log(`compountwillunmount called`)
    }

    render() {
        console.log(`compount rendered`)
        return (
            <div className="container">
                <div className="title">
                    <h3>Counter</h3>
                </div>
                <div>
                    <h1>number = {this.props.num }</h1>
                </div>

                <div>
                   {
                    this.state.view ? (
                        <h1> Task Completed </h1>
                    ) : (
                        <div>
                            <h1>Need More counts</h1>
                            <button onClick={this.incProps.bind(this)} className='btn btn-success'>Increment</button>
                        </div>
                    )
                   }
                </div>
            </div>
        )
    }
}

// default props
//Component.defaultProps
Counter.defaultProps = {
    num: 0
}