import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { useParams,useNavigate } from 'react-router-dom'
import axios from 'axios'

let URL = "http://localhost:5000"

function Update() {
    const [recipe,setRecipe] = useState({
        name: '',
        image: '',
        preTime: '',
        servings: '',
        foodType: 0,
        ingredients: "",
        preparation: "" 
    })

    let Navigate = useNavigate()
    let params = useParams()

    // to read the data
    let readData = async() => {
        await axios.get(`${URL}/recipes/${params.id}`)
        .then(res => {
            console.log(`single data =`, res)
            setRecipe(res.data)
        }).catch(err => toast.error(err.message));
    }

    useEffect(() => {
        readData()
    },[])
    const readInput = (e) => {
        const {name,value} = e.target
        setRecipe({...recipe, [name]:value})
    }
    const submitHandler = async (e) => {
        e.preventDefault()
        try {
            console.log(`recipe =` , recipe)
            await axios.patch(`${URL}/recipes/${params.id}`,recipe)
            .then(res => {
                toast.success("Recipe updated successfully!")
                Navigate(`/`)
            }).catch(err => toast.error(err.message))
        }catch (err) {
            toast.error(err.message)
        } 
    }
  return (
    <div className='container'>
        <div className="row">
            <div className="col-md-12 text-center">
                <h3 className="display-3 text-secondary">Update Recipe</h3>
            </div>
        </div>

        <div className="row">
            <div className="col-md-6 offset-md-3">
                <div className="card">
                    <div className="card-body">
                        <form autoComplete="off" onSubmit={submitHandler}>
                            <div className="form-group mt-2">
                            <label htmlFor="name">Recipe Name</label>
                            <input type="text" name="name" value={recipe.name} onChange={readInput} id="name" className="form-control" />
                            </div>

                            <div className="form-group mt-2">
                            <label htmlFor="image">Recipe Image (Paste url address)</label>
                            <input type="url" name="image" value={recipe.image} onChange={readInput} id="image" className="form-control" />
                            </div>

                            <div className="form-group mt-2">
                            <label htmlFor="preTime">Preparation Time (hh:mm)</label>
                            <input type="text" name="preTime" value={recipe.preTime} onChange={readInput} id="preIme" className="form-control" />
                            </div>

                            <div className="form-group mt-2">
                            <label htmlFor="servings">Number of Servings</label>
                            <input type="number" name="servings" value={recipe.servings} onChange={readInput}id="servings" className="form-control" />
                            </div>

                            <div className="form-group mt-2">
                                <label htmlFor="foodType">FoodType</label>
                                <select name="foodType" value={recipe.foodType} onChange={readInput} id="foodType" className='form-control'>
                                    <option value="null">Choose Food Type</option>
                                    <option value="veg">Veg</option>
                                    <option value="non-veg">Non-Veg</option>
                                    <option value="dessert">Dessert</option>
                                    <option value="soup">Soup</option>
                                    <option value="juice">Juice</option>
                                </select>
                            </div>
                            <div className="form-group mt-2">
                            <label htmlFor="ingredients">Ingreadients</label>
                            <textarea name="ingredients" value={recipe.ingredients} onChange={readInput} cols={30}  rows={10} id="ingredients" className="form-control" />
                            </div>
                            <div className="form-group mt-2">
                            <label htmlFor="preparation">Cooking Steps</label>
                            <textarea name="preparation" value={recipe.preparation} onChange={readInput} cols={30}  rows={10}  id="preparation" className="form-control" />
                            </div>

                            <div className="form-group mt-2">
                                <input type="submit" value="Update Recipe" className="btn btn-success" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Update
