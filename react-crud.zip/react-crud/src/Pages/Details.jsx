import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { NavLink, useParams , useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

let URL = 'http://localhost:5000'

function Details(props) {
  const [recipe, setRecipe] = useState(false)

  // to read id from router
  let params = useParams()
  let navigate = useNavigate()

  const readData = async () => {
    await axios.get(`${URL}/recipes/${params.id}`)
    .then(res => {
      console.log(`single =`, res)
      setRecipe(res.data)
    }).catch(err => toast.error(err.message));
  }

  useEffect(() => {
    readData()
  },[])

  const deleteRecipe = async (id) => {
    try {
      if(window.confirm(`Are you sure you want to delete recipe${id}`)){
        await axios.delete(`${URL}/recipes/${id}`)
        .then(res => {
          toast.success('Recipe deleted successfully')
            navigate(`/`)
        }).catch(err => toast.error(err.message))
      }
    } catch (err) {
      toast.error(err.message)
    }
  }
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
          <h3 className="dispaly-3 text-success">Details</h3>
        </div>
      </div>
      <div className="row">
        <div className="col-md-8 offset-md-2">
          <div className="card">
            <img src={recipe?.image} alt="no pic" className='card-img-top' />
            <div className="card-body">
              <h3 className="text-success">{recipe?.name}</h3>

              <ul className="list-group">
                <li className="list-group-item">
                  <strong>Preparation Time</strong>
                  <span className="text-success float-end">{recipe?.preTime} min</span>
                </li>

                <li className="list-group-item">
                  <strong>Servings</strong>
                  <span className="text-success float-end">{recipe?.servings} persons</span>
                </li>

                <li className="list-group-item">
                  <strong>Food Type</strong>
                  <span className="text-success float-end">{recipe?.foodType}</span>
                </li>

                <li className="list-group-item">
                  <strong>Ingradients</strong>
                  <span className="text-success float-end">{recipe?.ingredients} </span>
                </li>

                <li className="list-group-item">
                  <strong>Preparation</strong>
                  <span className="text-success float-end">{recipe?.preparation} </span>
                </li>
              </ul>
            </div>

            {/* edit option */}
            <div className="card-footer">
              <NavLink to={`/edit/${recipe?.id}`} className="btn btn-info">Edit Recipe</NavLink>

              <button onClick={() => deleteRecipe(recipe?.id)} className="btn btn-danger float-end">
                Delete Recipe
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Details
