import React from 'react'

function Pnf() {
  return (
    <div className='container'>
        <div className="row">
            <div className="col-md-12 text-center mt-5">
                <h3 className="dispaly-3 text-danger">
                    Requested Page Not Found
                </h3>
                <h1 className="display-1 text-danger">
                    404 Error
                </h1>
            </div>
        </div>
    </div>
  )
}

export default Pnf
